﻿using Pokedex.Models;
using System.Data.Entity;
using System.Data.Entity.ModelConfiguration.Conventions;

namespace Pokedex.DAL
{
    public class DexContext :DbContext
    {
        public DexContext(): base("DexContext")
        {
        }

        public DbSet<PKMN> PKMNs { get; set; }
        public DbSet<TMHM> TMHMs { get; set; }
        public DbSet<Map> Maps { get; set; }
        public DbSet<CanLearn> CanLearns { get; set; }
        public DbSet<FoundAt> FoundAts { get; set; }
        public DbSet<Evolution> Evolutions { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Conventions.Remove<PluralizingTableNameConvention>();
        }

    }
}