﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace Pokedex.ViewModels
{
    public class EvoGroup
    {

        public int PKMNNum { get; set; }
        public int Lvl { get; set; }
        public string Notes { get; set; }

    }
}